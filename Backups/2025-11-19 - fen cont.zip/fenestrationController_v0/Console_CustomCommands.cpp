#include "Console_CustomCommands.h"
#include <P1AM.h>

extern SerialConsole* console = nullptr;

const char* HelpMsg1 = "";

void c_InitializeSerialConsole(){
  // set up the serial console
  console = new SerialConsole(
      15, // number of commands
      50, // maximum character count of any full command line (with arguments)
      15, // maximum character count of any command
      10, // maximum character count of any single argument
      5,  // maximum number of arguments allowed in a single command line
      1   // the scan period (set to 1ms to let OSBos control this)
    );

  strcpy(console->Triggers[0], "test");
  console->Functions[0] = c_Test;

  strcpy(console->Triggers[1], "do");
  console->Functions[1] = c_DiscreteOutput;
  console->HelpMsg[1] = "Digital Output command.\nTurn a digital output on or off.\ndo <slot> <channel> <state>";

  strcpy(console->Triggers[2], "dr");
  console->Functions[2] = c_DiscreteRead;
  console->HelpMsg[2] = "Digital Read command.\nRead the state of a digital output.\ndr <slot> <channel>";
}

void c_DiscreteOutput(){
  uint8_t slot    = strtol(console->Arguments[1], NULL, 10);
  uint8_t channel = strtol(console->Arguments[2], NULL, 10);
  uint8_t state   = strtol(console->Arguments[3], NULL, 10);

  Serial.print("Attempting to write ");
  Serial.print(state);
  Serial.print(" to channel ");
  Serial.print(channel);
  Serial.print(" on slot ");
  Serial.print(slot);
  Serial.println(".");

  if(
    (0 < slot && slot < 2) &&
    (0 < channel && channel < 16) &&
    (-1 < state && state < 2)
    ){
    P1.writeDiscrete(state, slot, channel);
  }
  else{
    Serial.println("Invalid state, slot, or channel.");
  }
}

void c_Test(){
  Serial.println("Console test triggered");
}

void c_DiscreteRead(){
  uint8_t slot    = strtol(console->Arguments[1], NULL, 10);
  uint8_t channel = strtol(console->Arguments[2], NULL, 10);

  uint8_t reading = -1;

  Serial.print("Attempting to read value of channel ");
  Serial.print(channel);
  Serial.print(" on slot ");
  Serial.print(slot);
  Serial.print(" : ");

  if(
    (0 < slot && slot < 2) &&
    (0 < channel && channel < 16)
    ){
    reading = P1.readDiscrete(slot, channel);
    Serial.println(reading);
  }
  else{
    Serial.println("Invalid state, slot, or channel.");
  }
}