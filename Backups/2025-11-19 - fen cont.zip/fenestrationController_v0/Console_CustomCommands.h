#ifndef CONSOLE_CUSTOMCOMMANDS
#define CONSOLE_CUSTOMCOMMANDS

#include "SerialConsole.h"
#include <P1AM.h>

extern SerialConsole* console;

void c_InitializeSerialConsole();

void c_DiscreteOutput();
void c_DiscreteRead();
void c_Test();

#endif