#ifndef THREAD_WEBSERVER
#define THREAD_WEBSERVER

#include <SPI.h>
#include <Ethernet.h>

struct WebSvrDef {
	byte mac[6];
	IPAddress ip;
	EthernetServer* server;
};

extern WebSvrDef WebSvr;

void initWebServer();

void thread_WebServer();

String WebSvr_GetRequestPath(String request);

void WebSvr_JsonResponse(EthernetClient client, String json, int code = 200, String reason = "OK");
void WebSvr_404Response(EthernetClient client);

void WebSvr_Get_Pressure(EthernetClient client);

#endif