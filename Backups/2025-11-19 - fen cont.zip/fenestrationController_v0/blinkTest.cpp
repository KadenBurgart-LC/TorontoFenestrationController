#include "blinkTest.h"

BlinkTestDataDef BlinkTestData = {
	1000,
	0,
	false
};

void thread_BlinkTest(){
	BlinkTestData.currentState = !BlinkTestData.currentState;

	P1.writeDiscrete(BlinkTestData.currentState, 1, 2);
}