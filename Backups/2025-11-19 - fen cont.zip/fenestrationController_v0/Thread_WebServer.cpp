#include "Thread_WebServer.h"

WebSvrDef WebSvr = {
	{0xDE, 0xAD, 0xEF, 0xFE, 0xED},
	IPAddress(192,168,1,177),
	nullptr
};

void initWebServer(){
	Ethernet.begin(WebSvr.mac, WebSvr.ip);

	// Check for Ethernet hardware present
	if (Ethernet.hardwareStatus() == EthernetNoHardware) {
		Serial.println("Ethernet shield was not found. Can not initialize webserver.");
	}
	else if (Ethernet.linkStatus() == LinkOFF) {
		Serial.println("Ethernet cable is not connected. Can not initialize webserver.");
	}
	else{
		WebSvr.server = new EthernetServer(80);
		WebSvr.server->begin();

		Serial.print("Starting local server at ");
		Serial.println(Ethernet.localIP());
	}
}

/* Check and see if client requests have come in. Read the requests. Grab the requested path.
 * Use the path to route to an appropriate action and respond.
 */
void thread_WebServer(){
	EthernetClient client = WebSvr.server->available();

	if(client){
		// Read the incoming request
	    String request = "";
	    while (client.available()) {
	      request += (char)client.read();
	    }

	    Serial.println("Web Server request received: ");
	    String path = WebSvr_GetRequestPath(request);
	    Serial.println(path);

	    if(path == "/get/pressure") WebSvr_Get_Pressure(client);

		delay(1);
		client.stop();
	}
}

/* When we receive an HTTP request there is a bunch of information in there that we don't need, but we
 * DO need the path. The path comes in on the first line between the first two spaces.
 * This function grabs the text between the first two spaces and returns it.
 */
String WebSvr_GetRequestPath(String request){
	String path;

	int space1 = request.indexOf(' ');
	int space2 = request.indexOf(' ', space1 + 1);

	path = request.substring(space1+1, space2);

	return path;
}

void WebSvr_JsonResponse(EthernetClient client, String json, int code, String reason){
	String response = R"===(
HTTP/1.1 {{{code}}} {{{reason}}}
Content-Type: application/json
Access-Control-Allow-Origin: *

{{{JSON}}})===";

	response.replace("{{{code}}}", String(code));
	response.replace("{{{reason}}}", String(reason));
	response.replace("{{{JSON}}}", String(json));

	client.print(response);
}

void WebSvr_404Response(EthernetClient client){
	String response = R"===(
HTTP/1.1 404 Not Found
Content-Type: text/plain
Access-Control-Allow-Origin: *

404 Not Found: The requested resource does not exist.)===";

	client.print(response);
}

void WebSvr_Get_Pressure(EthernetClient client){
	String response = R"===({"millis":{{{millis}}},"pressure":{{{pressure}}}})===";

	response.replace("{{{millis}}}", String(millis()));
	response.replace("{{{pressure}}}", "100");

	WebSvr_JsonResponse(client, response);
}