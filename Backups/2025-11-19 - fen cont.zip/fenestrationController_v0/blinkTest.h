#ifndef BLINKTEST_H
#define BLINKTEST_H

#include <Arduino.h>
#include <P1AM.h>

struct BlinkTestDataDef {
	unsigned int blinkHalfPeriod_ms;
	unsigned long lastAction_ms;
	bool currentState;
};

void thread_BlinkTest();

#endif